import os
import sys
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint

# Ensure UTF-8 encoding for console output
sys.stdout.reconfigure(encoding='utf-8')

# Paths
DATA_DIR = 'processed_data'
MODEL_PATH = 'model/smartbin.keras'

# Parameters
IMG_SIZE = (150, 150)
BATCH_SIZE = 32
EPOCHS = 10  # You can increase if needed

# Data loaders
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_data = datagen.flow_from_directory(
    DATA_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='training',
    shuffle=True
)

val_data = datagen.flow_from_directory(
    DATA_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='validation',
    shuffle=True
)

# Load MobileNetV2 base
base_model = MobileNetV2(input_shape=IMG_SIZE + (3,), include_top=False, weights='imagenet')
base_model.trainable = False  # Freeze base layers

# Add custom layers
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(64, activation='relu')(x)
predictions = Dense(3, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.0001),
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# Save model to absolute path (for debug)
os.makedirs('model', exist_ok=True)
print("Saving model to:", os.path.abspath(MODEL_PATH))

# Save model after each epoch
checkpoint = ModelCheckpoint(MODEL_PATH, monitor='val_accuracy', save_best_only=False, verbose=1)

# Train the model
history = model.fit(
    train_data,
    epochs=EPOCHS,
    validation_data=val_data,
    callbacks=[checkpoint]
)

print("✅ Model training complete. Model saved to:", MODEL_PATH)
