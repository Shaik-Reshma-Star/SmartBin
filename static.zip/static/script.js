// Just check if files are selected before form submission
function validateWasteForm() {
    let file = document.getElementById("wasteImage").files[0];
    if (!file) {
        alert("⚠️ Please select a waste image before submitting!");
        return false; // Stop form submission
    }
    return true; // Allow form submission
}

function validateProofForm() {
    let file = document.getElementById("proofImage").files[0];
    if (!file) {
        alert("⚠️ Please select a proof image before submitting!");
        return false; // Stop form submission
    }
    return true; // Allow form submission
}
